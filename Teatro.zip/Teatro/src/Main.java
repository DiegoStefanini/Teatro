import java.util.*;

public class Main {
    public static void main(String[] args) {
      Teatro RisorsaCondivisa = new Teatro(); 
      for (int i = 0; i != 7; i++) {
          Biglietteria cassa = new Biglietteria(RisorsaCondivisa); 
          Thread thread = new Thread(cassa); 
          thread.start(); 
      }
      while (true) {
        Thread.sleep(10000);
        RisorsaCondivisa.IniziaSpettacolo(); 
      }
      
    }
    
}