public class Teatro {
    private boolean[][] Matrice; // Matrice per tenere traccia dei posti (true = occupato, false = libero)
    private int rigaCentro = 7; // Riga centrale
    private int colonnaCentro = 23; // Colonna centrale
    private int Rimasti; 
    public Teatro() {
      rimasti = 15*46;
      Matrice = new boolean[15][46];
    }
    // questo pezzo fatto con chatgpt 
    public synchronized int CompraBiglietto() {
        for (int distanza = 0; distanza < Math.max(rigaCentro, colonnaCentro); distanza++) {
            // Controlla i posti nelle righe e colonne più vicine al centro
            for (int r = -distanza; r <= distanza; r++) {
                for (int c = -distanza; c <= distanza; c++) {
                    if (Math.abs(r) + Math.abs(c) == distanza) {
                        int riga = rigaCentro + r;
                        int colonna = colonnaCentro + c;

                        if (riga >= 0 && riga < 15 && colonna >= 0 && colonna < 46 && !Matrice[riga][colonna]) {
                            Matrice[riga][colonna] = true; // Segna il posto come occupato
                            Rimasti--; 
                            return (riga * 46) + colonna; // Restituisce il numero del biglietto
                        }
                    }
                }
            }
        }
        return -1; // Se non ci sono posti disponibili
    }
    public int GetRimasti() {
      return Rimasti; 
    }
    public void IniziaSpettacolo () {
      Rimasti = 15*46;
      Matrice = new boolean[15][46]; 
    }
}
