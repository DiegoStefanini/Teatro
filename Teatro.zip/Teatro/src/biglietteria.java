public class Biglietteria implements Runnable{
  Teatro teatro; 
  public Biglietteria(Teatro t) {
    teatro = t; 
  }
  public void run () { 
    int biglietto = teatro.CompraBiglietto(); 
    while (biglietto != -1) {
        biglietto = teatro.CompraBiglietto(); 
        System.out.println("Sono Rimasti " + teatro.GetRimasti());
    }
    System.out.println("I biglietti sono finiti per questo spettacolo "); 
  }
}